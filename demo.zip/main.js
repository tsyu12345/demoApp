//円オブジェクト
class Elps {
    constructor(x, y, dia) {
        this.dia = dia;
        this.x = x;
        this.y = y;
    }

    draw(context) {
        context.beginPath();
        context.arc(this.x, this.y, this.dia, 0 * Math.PI / 180, 360 * Math.PI / 180, false);
        context.strokeStyle = 'rgba(255, 0, 0, 1)';
        context.lineWidth = 3;
        context.closePath();
        context.stroke();
    }

    move(x, y) {
        this.x = x;
        this.y = y;
    }

    delete() {
        //this.context.save()
        context.clearRect(this.x - this.dia / 2 - 12, this.y - this.dia / 2 - 12, this.dia + 25, this.dia + 25);
    }
}

//ユーザーが描く線のオブジェクト
class DragLines {
    constructor(context) {
        this.context = context
        this.isDrag = false;
    }

    draw(sx, sy, ex, ey) {
        this.context.save();
        this.context.lineCap = 'round';
        this.context.lineWidth = "3";
        this.context.strokeStyle = "blue";
        console.log('here!!');
        this.context.beginPath();
        this.context.moveTo(sx, sy);
        this.context.lineTo(ex, ey);
        this.context.closePath();
        this.context.stroke();


        this.context.restore();
    }

}


//grobal propatyes
const dia = 20;
const start_elps = new Elps(160, 190, dia);
const end_elps = new Elps(300, 190, dia);
const canvas = document.getElementById('draw_area');
const context = canvas.getContext('2d');
const drag_line = new DragLines(context);
const draw_text = document.getElementById('draw_text');
const side_text = document.getElementById('side_text');
const side_img  = document.getElementById('SideImg');
const a_point = [[160, 190, 300, 190], [210, 180, 210, 300], [250, 200, 210, 340]];
const i_point = [[156, 179, 224, 265], [261, 189, 297, 283]];
let complete = [false, false, false, false, false,]; //文字の終了状態を示す[あ、い、う、え、お]

//other functions
function dist(x1, y1, x2, y2) {
    return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
}

function draw_line() {
    canvas.addEventListener('mouseout', e => {
        drag_line.isDrag = false;
    });

    canvas.addEventListener('mouseup', e => {
        //console.log('mouse released')
        drag_line.isDrag = false;
    });

    canvas.addEventListener('mousedown', e => {
        drag_line.isDrag = true;
    })

    canvas.addEventListener('mousemove', e => {
        const downX = e.offsetX;
        const downY = e.offsetY;

        let prex = downX;
        let prey = downY;
        //drag_line.isDrag = true;
        if (drag_line.isDrag === true) {
            drag_line.draw(prex, prey, downX, downY);
            prex = downX;
            prey = downY;

        } else {
            return;
        }
    });
}

function next_elps(sx, sy, ex, ey) {
    start_elps.delete();
    end_elps.delete();
    start_elps.move(sx, sy);
    end_elps.move(ex, ey);
    //start_elps.draw(context);s
    //end_elps.draw(context);
}



function next(point_data, next_text, next_side, next_path) {
    console.log('next : ' + next_text);
    let count = 0;
   // drag_line.context.clearRect(0, 0, canvas.width, canvas.height);  
    canvas.addEventListener('mousemove', e => {
        console.log(complete);
        if(drag_line.isDrag) {
            for(let i = 0; i < point_data.length; i++) {
                //console.log('for : ' + i);
                if(dist(e.offsetX, e.offsetY, end_elps.x, end_elps.y) < dia && count === i-1) {
                    //console.log(count);
                    next_elps(point_data[i][0], point_data[i][1], point_data[i][2], point_data[i][3]);
                    start_elps.draw(context);
                    end_elps.draw(context);
                    count ++;
                }
            }
            if(count === point_data.length-1) {//最終画の処理
                //console.log(count);
                if(dist(e.offsetX, e.offsetY, end_elps.x, end_elps.y) < dia / 2) {
                    complete[0] = true;
                    count++;
                }
            }
        }
        console.log(count);
        if(count === point_data.length) {
            draw_text.textContent = next_text;
            side_text.textContent = next_side;
            side_img.setAttribute('src', next_path);
            context.clearRect(0, 0, canvas.width, canvas.height);
            count = 0;
            console.log(drag_line.isDrag);   
            return ;       
        }
        
    });
}

function main() {
    draw_line();
    start_elps.draw(context);
    end_elps.draw(context);
    next(a_point, 'い', 'いちご', 'images/itigo.png'); //あ
    if(complete[0] === true){
        next(i_point, 'う', 'うどん', 'images/itigo.png');　//い
    }
    return ;
        //canvas.removeEventListener('mousemove', next);
    
    /*
    let count = 0;
    canvas.addEventListener('mousemove', e => {
        if(drag_line.isDrag) {
            for(let i = 0; i < a_point.length; i++) {
                if(i === 0) {
                    start_elps.draw(context);
                    end_elps.draw(context);
                }
                //console.log('for : ' + i);
                if(dist(e.offsetX, e.offsetY, end_elps.x, end_elps.y) < dia / 2 && count === i-1) {
                    //console.log(count);
                    next_elps(a_point[i][0], a_point[i][1], a_point[i][2], a_point[i][3]);
                    start_elps.draw(context);
                    end_elps.draw(context);
                    count ++;
                }
            }
            if(count === a_point.length-1) {
                //console.log(count);
                if(dist(e.offsetX, e.offsetY, end_elps.x, end_elps.y) < dia / 2) {
                    complete[0] = true;
                    count++;
                }
            }
        }
        console.log(count);
        if(count === a_point.length) {
            draw_text.textContent = 'い';
            side_text.textContent = 'いちご';
            side_img.setAttribute('src', 'images/itigo.png');
            console.log(drag_line.isDrag);
            drag_line.context.clearRect(0, 0, canvas.width, canvas.height);            
        }
    });
    */
    //window.requestAnimationFrame(main)
}
main();

//window.addEventListener('load', loop, false);